# Setlhare Utility Solutions — Website

This repository is a Vite + React + Tailwind site with a Vercel serverless function for the contact form.

## Features
- Single-page React app (Home, About, Services, Contact)
- TailwindCSS for styling
- `/api/contact` Vercel function that sends email via Nodemailer

## Setup (local)
1. Install dependencies:
   ```
   npm install
   ```
2. Start dev server:
   ```
   npm run dev
   ```

## Environment variables (Vercel)
Set these in your Vercel project settings (Environment Variables):

- `EMAIL_USER` - the SMTP username (usually your email address, e.g. setlhare.omphemetse@gmail.com)
- `EMAIL_PASS` - the SMTP password (for Gmail: use an App Password if 2FA is enabled)
- `EMAIL_TO`   - (optional) destination email; defaults to `EMAIL_USER`
- `SMTP_HOST`  - (optional) SMTP host (defaults to smtp.gmail.com)
- `SMTP_PORT`  - (optional) SMTP port (defaults to 465)
- `SMTP_SECURE` - (optional) 'true' or 'false' (defaults to 'true' for port 465)

### Gmail notes
- For Gmail, enable 2-Step Verification and create an App Password, then use it as `EMAIL_PASS`.
- Alternatively, use an SMTP provider (SendGrid, Mailgun) and update the SMTP credentials accordingly.

## Deploy to Vercel
1. Push this repo to GitHub.
2. Import the repo to Vercel.
3. Add the environment variables in the project settings.
4. Deploy — Vercel will handle serverless function installation (it will install nodemailer from package.json if present).

## Adding nodemailer to the deployment
Because the Vercel function uses `nodemailer`, add it to your project dependencies before deploying:

```
npm install nodemailer
```

(You can install it locally, commit a package-lock.json, and then push. Vercel will install on its side too.)

## Support
If you want, I can:
- Add deployment-friendly scripts / GitHub Actions
- Set up SendGrid instead of SMTP
- Create a Netlify or plain-Express back-end instead
