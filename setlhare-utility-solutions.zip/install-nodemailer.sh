# Run this in the project root to install nodemailer before deploying:

npm install nodemailer
