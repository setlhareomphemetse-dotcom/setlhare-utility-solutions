import React, { useState } from "react";

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState(null);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSending(true);
    setStatus(null);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setStatus({ ok: true, msg: 'Message sent — we will contact you shortly.' });
        setForm({ name: "", email: "", phone: "", message: "" });
      } else {
        const data = await res.json().catch(() => ({}));
        setStatus({ ok: false, msg: data.error || 'Failed to send message. Please try again later.' });
      }
    } catch (err) {
      setStatus({ ok: false, msg: 'Network error — please try again.' });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold">S</div>
            <div>
              <h1 className="text-lg font-semibold">Setlhare Utility Solutions</h1>
              <p className="text-sm text-gray-500">Estate utilities monitoring — water &amp; electricity</p>
            </div>
          </div>

          <nav className="hidden md:flex gap-6 items-center text-sm">
            <a href="#home" className="hover:text-indigo-600">Home</a>
            <a href="#about" className="hover:text-indigo-600">About</a>
            <a href="#services" className="hover:text-indigo-600">Services</a>
            <a href="#contact" className="text-white bg-indigo-600 px-4 py-2 rounded-md hover:opacity-95">Contact</a>
          </nav>

          <button
            className="md:hidden p-2 rounded-md border"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            ☰
          </button>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t">
            <div className="px-6 py-4 flex flex-col gap-3">
              <a href="#home" onClick={() => setMobileOpen(false)}>Home</a>
              <a href="#about" onClick={() => setMobileOpen(false)}>About</a>
              <a href="#services" onClick={() => setMobileOpen(false)}>Services</a>
              <a href="#contact" onClick={() => setMobileOpen(false)} className="text-white bg-indigo-600 px-4 py-2 rounded-md">Contact</a>
            </div>
          </div>
        )}
      </header>

      <main>
        <section id="home" className="max-w-6xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold leading-tight">Reliable utilities monitoring for estates</h2>
            <p className="mt-4 text-gray-600">We help estate managers reduce waste, detect faults early, and ensure continuous service by actively monitoring water and electricity usage across properties.</p>

            <ul className="mt-6 grid gap-3">
              <li className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-md bg-indigo-50 flex items-center justify-center font-semibold text-indigo-600">01</div>
                <div>
                  <strong>Real-time alerts</strong>
                  <div className="text-sm text-gray-600">Automated notifications for leaks, spikes, and outages.</div>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-md bg-indigo-50 flex items-center justify-center font-semibold text-indigo-600">02</div>
                <div>
                  <strong>Usage analytics</strong>
                  <div className="text-sm text-gray-600">Actionable reports to reduce consumption and cost.</div>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-md bg-indigo-50 flex items-center justify-center font-semibold text-indigo-600">03</div>
                <div>
                  <strong>Maintenance coordination</strong>
                  <div className="text-sm text-gray-600">Fast response and scheduled checks to protect infrastructure.</div>
                </div>
              </li>
            </ul>

            <div className="mt-6 flex gap-3">
              <a href="#services" className="px-5 py-3 bg-indigo-600 text-white rounded-md shadow hover:opacity-95">Our Services</a>
              <a href="#contact" className="px-5 py-3 border rounded-md">Get in touch</a>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md">
            <h3 className="font-semibold text-lg">Quick Metrics (example)</h3>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="p-4 border rounded-md">
                <div className="text-sm text-gray-500">Active Estates</div>
                <div className="text-2xl font-bold">28</div>
              </div>
              <div className="p-4 border rounded-md">
                <div className="text-sm text-gray-500">Alerts this month</div>
                <div className="text-2xl font-bold">7</div>
              </div>
              <div className="p-4 border rounded-md">
                <div className="text-sm text-gray-500">Avg response</div>
                <div className="text-2xl font-bold">1.3 hrs</div>
              </div>
              <div className="p-4 border rounded-md">
                <div className="text-sm text-gray-500">Water saved</div>
                <div className="text-2xl font-bold">1,200 m³</div>
              </div>
            </div>
          </div>
        </section>

        <section id="about" className="bg-white py-12">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-semibold">About Setlhare Utility Solutions</h3>
                <p className="mt-4 text-gray-600">We specialise in monitoring and managing water and electricity systems for residential and mixed-use estates. Our goal is to keep utilities efficient, costs down, and residents satisfied through a mix of smart monitoring, prompt maintenance coordination, and clear reporting.</p>

                <ul className="mt-4 list-disc list-inside text-gray-600">
                  <li>Experienced technicians and monitoring specialists</li>
                  <li>Customizable alerting & reporting</li>
                  <li>Transparent pricing and fast SLA options</li>
                </ul>
              </div>

              <div className="rounded-lg overflow-hidden shadow-md">
                <img src="https://images.unsplash.com/photo-1503602642458-232111445657?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder" alt="Utilities monitoring" className="w-full h-64 object-cover" />
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="max-w-6xl mx-auto px-6 py-12">
          <h3 className="text-2xl font-semibold">Services</h3>
          <p className="text-gray-600 mt-2">Comprehensive services tailored for estates of all sizes.</p>

          <div className="mt-6 grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">Monitoring & Alerts</h4>
              <p className="text-sm text-gray-600 mt-2">24/7 monitoring of consumption and automatic alerts for anomalies.</p>
            </div>
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">Leak & Fault Detection</h4>
              <p className="text-sm text-gray-600 mt-2">Early detection systems to prevent large-scale damage or losses.</p>
            </div>
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">Reporting & Insights</h4>
              <p className="text-sm text-gray-600 mt-2">Regular usage reports and recommendations for cost savings.</p>
            </div>
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">Maintenance Coordination</h4>
              <p className="text-sm text-gray-600 mt-2">We coordinate technicians and verify work to completion.</p>
            </div>
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">IoT Integrations</h4>
              <p className="text-sm text-gray-600 mt-2">Integrate smart meters and sensors for deeper insights.</p>
            </div>
            <div className="p-6 bg-white border rounded-lg shadow-sm">
              <h4 className="font-semibold">Custom SLAs</h4>
              <p className="text-sm text-gray-600 mt-2">Choose response times and reporting cadence that suit your estate.</p>
            </div>
          </div>
        </section>

        <section id="contact" className="bg-white py-12">
          <div className="max-w-4xl mx-auto px-6 grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold">Contact us</h3>
              <p className="text-gray-600 mt-2">Ready to improve your estate's utilities performance? Send us a message and we'll respond within one business day.</p>

              <div className="mt-6 space-y-4 text-sm text-gray-600">
                <div>
                  <strong>Email</strong>
                  <div>info@setlhareutilities.co.bw</div>
                </div>
                <div>
                  <strong>Phone</strong>
                  <div>+267 000 0000</div>
                </div>
                <div>
                  <strong>Office</strong>
                  <div>Gaborone, Botswana</div>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="p-6 border rounded-lg bg-gray-50">
              <div className="grid gap-3">
                <label className="text-sm">Full name</label>
                <input name="name" value={form.name} onChange={handleChange} required className="p-2 border rounded-md" />

                <label className="text-sm">Email</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} required className="p-2 border rounded-md" />

                <label className="text-sm">Phone</label>
                <input name="phone" value={form.phone} onChange={handleChange} className="p-2 border rounded-md" />

                <label className="text-sm">Message</label>
                <textarea name="message" value={form.message} onChange={handleChange} rows={4} className="p-2 border rounded-md" />

                <button type="submit" disabled={sending} className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded-md">{sending ? 'Sending...' : 'Send message'}</button>

                {status && (
                  <div className={`mt-3 text-sm ${status.ok ? 'text-green-600' : 'text-red-600'}`}>{status.msg}</div>
                )}

                <div className="text-xs text-gray-400 mt-2">By contacting you agree to allow Setlhare Utility Solutions to store and process your contact details for follow-up.</div>
              </div>
            </form>
          </div>
        </section>

        <footer className="bg-gray-800 text-gray-200 py-6 mt-8">
          <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm">© {new Date().getFullYear()} Setlhare Utility Solutions</div>
            <div className="flex gap-4 text-sm">
              <a href="#" className="hover:underline">Privacy</a>
              <a href="#" className="hover:underline">Terms</a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
